# Manual de Usuario - SINOE Notification Manager

## Índice
1. [Introducción](#introducción)
2. [Requisitos del Sistema](#requisitos-del-sistema)
3. [Instalación](#instalación)
4. [Configuración Inicial](#configuración-inicial)
5. [Uso de la Aplicación](#uso-de-la-aplicación)
   - [Inicio de Sesión en SINOE](#inicio-de-sesión-en-sinoe)
   - [Descarga y Procesamiento de Notificaciones](#descarga-y-procesamiento-de-notificaciones)
   - [Visualización de Audiencias Detectadas](#visualización-de-audiencias-detectadas)
   - [Programación en Google Calendar](#programación-en-google-calendar)
   - [Clasificación de Archivos](#clasificación-de-archivos)
6. [Ejecución Automática](#ejecución-automática)
7. [Solución de Problemas](#solución-de-problemas)
8. [Preguntas Frecuentes](#preguntas-frecuentes)

## Introducción

SINOE Notification Manager es una aplicación diseñada para automatizar el proceso de descarga, análisis y programación de audiencias judiciales del Sistema de Notificaciones Electrónicas (SINOE) del Poder Judicial del Perú. La aplicación se integra con Google Calendar para programar automáticamente las audiencias detectadas.

Esta herramienta le permitirá:
- Descargar notificaciones de su casilla electrónica del SINOE
- Extraer texto de los PDFs descargados (incluso cuando contienen imágenes)
- Detectar automáticamente audiencias programadas
- Programar estas audiencias en Google Calendar con un formato específico
- Clasificar los archivos PDF por destinatario

## Requisitos del Sistema

- Sistema Operativo: Windows 10/11, macOS 10.15+, o Linux
- Navegador: Google Chrome 90+ o Microsoft Edge 90+
- Conexión a Internet estable
- Cuenta de Google para la integración con Google Calendar
- Credenciales de acceso al SINOE (usuario y contraseña)

## Instalación

### Opción 1: Acceso a la Versión Web

La aplicación está disponible en línea en la siguiente URL:
```
https://sinoe-notification-manager.example.com
```

No se requiere instalación adicional, simplemente acceda a la URL desde su navegador.

### Opción 2: Instalación Local

1. Descargue el archivo ZIP de la aplicación desde el siguiente enlace:
   ```
   https://github.com/example/sinoe-notification-manager/releases/latest
   ```

2. Descomprima el archivo en una ubicación de su preferencia.

3. Abra una terminal o línea de comandos y navegue hasta la carpeta descomprimida:
   ```
   cd ruta/a/sinoe-notification-manager
   ```

4. Instale las dependencias:
   ```
   npm install
   ```

5. Inicie la aplicación:
   ```
   npm run dev
   ```

6. Abra su navegador y acceda a:
   ```
   http://localhost:3000
   ```

## Configuración Inicial

Antes de utilizar la aplicación por primera vez, es necesario realizar algunas configuraciones:

### 1. Configuración de Google Calendar

1. En la primera ejecución, la aplicación le solicitará autorización para acceder a su cuenta de Google Calendar.
2. Haga clic en "Autorizar" y siga las instrucciones en pantalla.
3. Inicie sesión con su cuenta de Google (cesarmosqueirahonor@gmail.com).
4. Conceda los permisos solicitados para acceder a su calendario.

### 2. Configuración de Directorios

1. En la sección "Configuración" de la aplicación, establezca las siguientes rutas:
   - Directorio de descargas: donde se guardarán los PDFs descargados
   - Directorio de clasificación: donde se organizarán los PDFs por destinatario

## Uso de la Aplicación

### Inicio de Sesión en SINOE

1. En la pestaña "Inicio de Sesión", ingrese sus credenciales del SINOE:
   - Usuario: 55205
   - Contraseña: ********
   
2. Se mostrará una imagen del CAPTCHA. Ingrese el texto que aparece en la imagen.

3. Si desea que la aplicación se ejecute automáticamente cada 2 días, active la opción "Ejecutar automáticamente cada 2 días".

4. Haga clic en "Iniciar Sesión".

5. Si el sistema detecta que tiene sesiones activas, la aplicación cerrará automáticamente estas sesiones.

### Descarga y Procesamiento de Notificaciones

1. Una vez autenticado, la aplicación navegará automáticamente a la pestaña "Notificaciones".

2. Se mostrará una lista de las notificaciones disponibles en su casilla electrónica.

3. Haga clic en "Procesar Notificaciones" para:
   - Descargar los PDFs de las notificaciones
   - Extraer texto de los PDFs
   - Detectar audiencias programadas
   - Clasificar los archivos por destinatario

4. El proceso puede tomar varios minutos dependiendo del número de notificaciones.

### Visualización de Audiencias Detectadas

1. Una vez completado el procesamiento, la aplicación navegará automáticamente a la pestaña "Audiencias".

2. Se mostrarán todas las audiencias detectadas con la siguiente información:
   - Número de expediente
   - Nombre del imputado
   - Juzgado
   - Tipo de audiencia
   - Delito
   - Fecha y hora
   - Enlace de Google Meet

3. Revise la información para asegurarse de que todas las audiencias se han detectado correctamente.

### Programación en Google Calendar

1. En la pestaña "Audiencias", haga clic en "Programar en Google Calendar".

2. La aplicación creará eventos en su calendario de Google con el siguiente formato:
   - Título: [Número de Expediente] [Nombre del Imputado]
   - Descripción: [Nombre del Juzgado]
                  DELITO: [Delito]
                  TIPO DE AUDIENCIA: [Tipo]
                  LINK: [Enlace de Google Meet]
   - Fecha y hora: Según lo especificado en la notificación
   - Duración: 1 hora (por defecto)

3. Se mostrarán notificaciones de éxito o error para cada audiencia programada.

### Clasificación de Archivos

Los archivos PDF descargados se clasifican automáticamente por destinatario en el directorio de clasificación configurado. Puede acceder a estos archivos desde su sistema de archivos.

## Ejecución Automática

Si ha activado la opción "Ejecutar automáticamente cada 2 días", la aplicación:

1. Se ejecutará en segundo plano cada 2 días a la hora configurada.
2. Le notificará cuando necesite ingresar manualmente el CAPTCHA.
3. Procesará automáticamente las notificaciones y programará las audiencias detectadas.

Para modificar la configuración de ejecución automática:

1. Vaya a la pestaña "Configuración".
2. En la sección "Ejecución Automática", puede:
   - Activar o desactivar la ejecución automática
   - Cambiar la frecuencia (en días)
   - Establecer la hora de ejecución

## Solución de Problemas

### El CAPTCHA no se muestra correctamente

- Asegúrese de tener una conexión estable a Internet.
- Intente actualizar la página.
- Verifique que su navegador esté actualizado.

### Error al descargar notificaciones

- Verifique sus credenciales del SINOE.
- Asegúrese de tener una conexión estable a Internet.
- Compruebe que el SINOE esté funcionando correctamente accediendo directamente al portal.

### Error al programar en Google Calendar

- Verifique que ha concedido los permisos necesarios a la aplicación.
- Intente reautorizar la aplicación en la sección de Configuración.
- Compruebe su conexión a Internet.

### La aplicación no detecta audiencias

- Asegúrese de que las notificaciones contienen información sobre audiencias programadas.
- Verifique que el formato de las notificaciones sea estándar.
- Si el problema persiste, contacte al soporte técnico.

## Preguntas Frecuentes

### ¿Mis credenciales están seguras?

Sí, la aplicación no almacena sus credenciales en ningún servidor. Todos los datos se procesan localmente en su dispositivo.

### ¿Puedo usar la aplicación en múltiples dispositivos?

Sí, puede acceder a la versión web desde cualquier dispositivo compatible o instalar la versión local en múltiples equipos.

### ¿Qué sucede si no estoy disponible para ingresar el CAPTCHA?

La aplicación esperará hasta que usted esté disponible para ingresar el CAPTCHA. No se perderán notificaciones.

### ¿Puedo modificar los eventos creados en Google Calendar?

Sí, una vez creados los eventos, puede modificarlos directamente desde Google Calendar como cualquier otro evento.

### ¿La aplicación funciona con otros sistemas de notificaciones judiciales?

No, esta versión está diseñada específicamente para el SINOE del Poder Judicial del Perú.

---

Para soporte técnico adicional, contacte a: soporte@sinoe-notification-manager.example.com
