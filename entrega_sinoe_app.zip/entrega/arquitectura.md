# Arquitectura de la Aplicación SINOE Notification Manager

## Visión General

La aplicación SINOE Notification Manager es una solución web diseñada para automatizar el proceso de descarga, análisis y programación de audiencias judiciales del Sistema de Notificaciones Electrónicas (SINOE) del Poder Judicial del Perú. La aplicación se integrará con Google Calendar para programar automáticamente las audiencias detectadas.

## Componentes Principales

### 1. Módulo de Autenticación
- **Propósito**: Gestionar el acceso al sistema SINOE.
- **Características**:
  - Interfaz para ingresar credenciales (usuario y contraseña)
  - Manejo manual del CAPTCHA por parte del usuario
  - Gestión de sesiones y cierre de sesiones activas

### 2. Módulo de Descarga de Notificaciones
- **Propósito**: Navegar por el SINOE y descargar las notificaciones.
- **Características**:
  - Navegación automatizada por el portal
  - Descarga de archivos PDF de notificaciones
  - Almacenamiento local de notificaciones

### 3. Módulo de Procesamiento de Documentos
- **Propósito**: Extraer texto e información relevante de los PDFs.
- **Características**:
  - Extracción de texto de PDFs
  - OCR para PDFs que contienen imágenes
  - Clasificación de archivos por destinatario

### 4. Módulo de Detección de Audiencias
- **Propósito**: Identificar audiencias programadas en las notificaciones.
- **Características**:
  - Algoritmos de detección para los tipos de audiencias especificados
  - Extracción de información relevante (número de expediente, imputado, juzgado, tipo de audiencia, delito, enlace)

### 5. Módulo de Integración con Google Calendar
- **Propósito**: Programar audiencias en Google Calendar.
- **Características**:
  - Autenticación con Google API
  - Creación de eventos con formato específico
  - Verificación de eventos creados

### 6. Interfaz de Usuario
- **Propósito**: Proporcionar una experiencia de usuario intuitiva.
- **Características**:
  - Dashboard principal
  - Visualización de notificaciones descargadas
  - Visualización de audiencias detectadas
  - Configuración de ejecución automática

## Tecnologías Propuestas

### Backend
- **Framework**: Next.js (para aprovechar las capacidades de servidor y cliente)
- **Lenguaje**: JavaScript/TypeScript
- **Bibliotecas**:
  - Puppeteer (para automatización de navegador)
  - pdf.js (para extracción de texto de PDFs)
  - Tesseract.js (para OCR)
  - Google API Client (para integración con Google Calendar)

### Frontend
- **Framework**: Next.js con React
- **Estilización**: Tailwind CSS
- **Componentes**: shadcn/ui

### Almacenamiento
- **Local**: Sistema de archivos para PDFs descargados
- **Base de datos**: SQLite (a través de D1 de Cloudflare) para metadatos y seguimiento

## Flujo de Trabajo

1. **Autenticación**:
   - El usuario inicia sesión en la aplicación
   - La aplicación navega al portal SINOE
   - El usuario ingresa manualmente el CAPTCHA cuando se solicita

2. **Descarga de Notificaciones**:
   - La aplicación navega a la sección de Casillas Electrónicas
   - Descarga las notificaciones disponibles
   - Almacena los PDFs localmente

3. **Procesamiento de Documentos**:
   - Extrae texto de los PDFs
   - Aplica OCR si es necesario
   - Clasifica los archivos por destinatario

4. **Detección de Audiencias**:
   - Analiza el texto para identificar audiencias programadas
   - Extrae información relevante de cada audiencia

5. **Programación en Calendario**:
   - Crea eventos en Google Calendar con el formato especificado
   - Proporciona confirmación visual de los eventos creados

6. **Revisión y Gestión**:
   - Permite al usuario revisar las audiencias programadas
   - Ofrece opciones para modificar o eliminar eventos

## Modos de Operación

### Modo Manual
- El usuario inicia el proceso cuando lo desea
- Completa manualmente el CAPTCHA cuando se solicita
- Revisa y confirma las audiencias detectadas antes de programarlas

### Modo Automático
- La aplicación se ejecuta automáticamente cada 2 días
- Notifica al usuario cuando necesita completar el CAPTCHA
- Programa automáticamente las audiencias detectadas

## Consideraciones de Seguridad

- Las credenciales se almacenarán de forma segura
- Se implementará autenticación OAuth para Google Calendar
- Se mantendrá un registro de actividades para auditoría
